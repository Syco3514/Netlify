import { db, json, getCookie, clearCookie } from './lib/utils.js';

export const handler = async (event) => {
  if (event.httpMethod !== 'POST') return json({ error:'Method not allowed' }, 405);
  const sid = getCookie(event,'sid');
  if (sid) { await db.del(`sessions/${sid}`).catch(()=>{}); }
  return {
    statusCode: 200,
    headers: { 'content-type':'application/json; charset=utf-8', 'set-cookie': clearCookie('sid') },
    body: JSON.stringify({ ok:true })
  };
};