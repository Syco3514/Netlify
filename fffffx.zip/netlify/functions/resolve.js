import { db, html, isBot } from './lib/utils.js';

export const handler = async (event) => {
  if (!['GET','HEAD'].includes(event.httpMethod)) {
    return { statusCode: 405, body: 'Method not allowed' };
  }

  const slug = (event.queryStringParameters?.slug || '').toLowerCase();
  if(!slug) return html(notFoundPage(), 404, securityHeaders());

  const link = await db.getJSON(`links/${slug}`);
  if(!link) return html(notFoundPage(), 404, securityHeaders());

  const ua = event.headers['user-agent'] || event.headers['User-Agent'] || '';
  const bot = isBot(ua);

  // increment clicks only for likely humans
  if(!bot && event.httpMethod !== 'HEAD'){
    try{
      const fresh = await db.getJSON(`links/${slug}`) || link;
      fresh.clicks = (fresh.clicks||0) + 1;
      await db.setJSON(`links/${slug}`, fresh);
    }catch{}
  }

  const headers = {
    ...securityHeaders(),
    'x-robots-tag': 'noindex, nofollow, noimageindex, nosnippet, noarchive',
    // Prevent link unfurl
    'cache-control': 'no-store, private, max-age=0',
  };

  // For bots: show a minimal page, no redirect, no OG tags.
  if(bot || event.httpMethod === 'HEAD'){
    return html(botPage(slug), 200, headers);
  }

  // For humans: JS-only redirect after ~2s. No meta refresh (bots could follow that).
  return html(humanRedirectPage(link.url), 200, headers);
};

function securityHeaders(){
  return {
    'content-security-policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'",
    'referrer-policy': 'no-referrer',
  };
}

function notFoundPage(){
  return `<!doctype html>
<html><head><meta charset="utf-8"><title>Not found</title>
<meta name="robots" content="noindex,nofollow">
<link rel="stylesheet" href="/styles.css"></head>
<body><div class="container"><div class="card"><h1>404</h1><p class="muted">Link not found</p><a class="btn" href="/">Go home</a></div></div></body></html>`;
}

function botPage(slug){
  return `<!doctype html>
<html><head><meta charset="utf-8">
<title>Link</title>
<meta name="robots" content="noindex,nofollow,noimageindex,nosnippet">
<link rel="stylesheet" href="/styles.css">
</head>
<body>
  <div class="container">
    <div class="card">
      <h1>Preview disabled</h1>
      <p class="muted">This short link cannot be previewed by bots.</p>
      <p class="muted">Slug: <span class="badge">${slug}</span></p>
    </div>
  </div>
</body></html>`;
}

function humanRedirectPage(target){
  const esc = target.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  return `<!doctype html>
<html><head><meta charset="utf-8">
<title>Redirecting…</title>
<meta name="robots" content="noindex,nofollow,noimageindex,nosnippet">
<link rel="stylesheet" href="/styles.css">
</head>
<body>
  <div class="container">
    <div class="card">
      <h1>Taking you there…</h1>
      <p class="muted">Redirecting in about 2 seconds.</p>
      <p><a class="btn" id="go" href="${esc}">Go now</a></p>
      <noscript><p class="muted">JavaScript is required to redirect automatically. Click the button above.</p></noscript>
    </div>
  </div>
  <script>
    const url = ${JSON.stringify(target)};
    setTimeout(()=>{ try{ location.replace(url); }catch(e){ location.href=url; } }, 2000);
  </script>
</body></html>`;
}