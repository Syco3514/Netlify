import { db, json, parseJSON, requireUser, isValidURL, isValidSlug, newSlug } from '../lib/utils.js';

export const handler = async (event) => {
  if (event.httpMethod !== 'POST') return json({ error:'Method not allowed' }, 405);
  const user = await requireUser(event);
  if(!user) return json({ error:'Unauthorized' }, 401);

  const { url, slug } = parseJSON(event);
  if(!isValidURL(url||'')) return json({ error:'Invalid URL (must start with http:// or https://)' }, 400);

  let finalSlug = (slug||'').trim();
  if(finalSlug){
    if(!isValidSlug(finalSlug)) return json({ error:'Invalid slug (3-30 chars: letters/numbers/-/_) or reserved' }, 400);
    const exists = await db.getJSON(`links/${finalSlug.toLowerCase()}`);
    if(exists) return json({ error:'Slug already in use' }, 409);
  } else {
    for(let i=0;i<5;i++){
      const s = newSlug();
      const exists = await db.getJSON(`links/${s.toLowerCase()}`);
      if(!exists){ finalSlug = s; break; }
    }
    if(!finalSlug) return json({ error:'Could not generate unique slug, try again' }, 500);
  }

  const link = { slug: finalSlug.toLowerCase(), url, ownerId: user.id, createdAt: Date.now(), clicks:0 };
  await db.setJSON(`links/${link.slug}`, link);
  await db.setJSON(`userLinks/${user.id}/${link.slug}`, { slug: link.slug, createdAt: link.createdAt });

  const base = process.env.SITE_URL || `https://${event.headers.host}`;
  return json({ ...link, short: `${base.replace(/\/$/,'')}/${link.slug}` });
};