import { json, requireUser } from './lib/utils.js';

export const handler = async (event) => {
  if (event.httpMethod !== 'GET') return json({ error:'Method not allowed' }, 405);
  const user = await requireUser(event);
  if(!user) return json({ error:'Unauthorized' }, 401);
  return json({ id:user.id, username:user.username, email:user.email });
};