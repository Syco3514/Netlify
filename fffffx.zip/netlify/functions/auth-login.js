import { db, json, parseJSON, verifyPassword, isEmail, newSessionId, setCookie } from './lib/utils.js';

export const handler = async (event) => {
  if (event.httpMethod !== 'POST') return json({ error:'Method not allowed' }, 405);
  const { identifier, password } = parseJSON(event);
  if(!identifier || !password) return json({ error:'Missing credentials' }, 400);

  let user = null;
  if(isEmail(identifier)) {
    const m = await db.getJSON(`emails/${identifier.toLowerCase()}`);
    user = m ? await db.getJSON(`users/${m.userId}`) : null;
  } else {
    const u = await db.getJSON(`usernames/${identifier.toLowerCase()}`);
    user = u ? await db.getJSON(`users/${u.userId}`) : null;
  }
  if(!user) return json({ error:'Invalid credentials' }, 401);
  const ok = await verifyPassword(password, user.passwordHash);
  if(!ok) return json({ error:'Invalid credentials' }, 401);

  const sid = newSessionId();
  await db.setJSON(`sessions/${sid}`, { userId: user.id, createdAt: Date.now(), expiresAt: Date.now() + 30*864e5 });

  return {
    statusCode: 200,
    headers: {
      'content-type':'application/json; charset=utf-8',
      'set-cookie': setCookie('sid', sid),
    },
    body: JSON.stringify({ id:user.id, username:user.username, email:user.email })
  };
};