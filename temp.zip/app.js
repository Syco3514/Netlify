const API = 'https://www.1secmail.com/api/v1/';
const state = {
  login: null,
  domain: null,
  address: null,
  autoRefresh: true,
  pollMs: 10000,
  timer: null,
  currentId: null
};

const $ = (s) => document.querySelector(s);
const els = {
  address: $('#address'),
  copyBtn: $('#copyBtn'),
  newBtn: $('#newBtn'),
  refreshBtn: $('#refreshBtn'),
  autoToggle: $('#autoToggle'),
  status: $('#status'),
  list: $('#messageList'),
  viewer: $('#viewer')
};

document.addEventListener('DOMContentLoaded', init);

function init(){
  loadFromStorage();
  bindEvents();
  if(state.login && state.domain){
    setAddressUI();
    startPolling();
    refreshInbox();
  } else {
    generateMailbox();
  }
}

function bindEvents(){
  els.copyBtn.addEventListener('click', copyAddress);
  els.newBtn.addEventListener('click', newAddress);
  els.refreshBtn.addEventListener('click', refreshInbox);
  els.autoToggle.addEventListener('change', (e)=>{
    state.autoRefresh = e.target.checked;
    localStorage.setItem('tm_auto', JSON.stringify(state.autoRefresh));
    startPolling();
  });
}

function loadFromStorage(){
  const login = localStorage.getItem('tm_login');
  const domain = localStorage.getItem('tm_domain');
  const auto = localStorage.getItem('tm_auto');
  if(login && domain){
    state.login = login;
    state.domain = domain;
    state.address = `${login}@${domain}`;
  }
  if(auto !== null){
    state.autoRefresh = JSON.parse(auto);
  }
  els.autoToggle.checked = state.autoRefresh;
}

function saveToStorage(){
  localStorage.setItem('tm_login', state.login);
  localStorage.setItem('tm_domain', state.domain);
}

async function generateMailbox(){
  setStatus('Generating address…');
  try{
    const res = await fetch(`${API}?action=genRandomMailbox&count=1`);
    const data = await res.json();
    const addr = data[0];
    const [login, domain] = addr.split('@');
    state.login = login; state.domain = domain; state.address = addr;
    saveToStorage();
    setAddressUI();
    clearInboxUI();
    startPolling();
    await refreshInbox();
    setStatus('New address ready');
  } catch(e){
    setStatus('Error generating address');
    console.error(e);
  }
}

function setAddressUI(){
  els.address.textContent = state.address || '—';
}

function clearInboxUI(){
  els.list.innerHTML = `<li class="muted">No messages yet…</li>`;
  els.viewer.innerHTML = `<div class="muted">Select a message to read</div>`;
  state.currentId = null;
}

function startPolling(){
  if(state.timer) clearInterval(state.timer);
  if(state.autoRefresh){
    state.timer = setInterval(refreshInbox, state.pollMs);
  }
}

async function refreshInbox(){
  if(!state.login) return;
  setStatus('Refreshing…');
  try{
    const url = `${API}?action=getMessages&login=${encodeURIComponent(state.login)}&domain=${encodeURIComponent(state.domain)}`;
    const res = await fetch(url);
    const messages = await res.json();
    renderMessageList(Array.isArray(messages) ? messages : []);
    setStatus(`Last updated ${new Date().toLocaleTimeString()}`);
  } catch(e){
    setStatus('Error fetching inbox');
    console.error(e);
  }
}

function renderMessageList(items){
  if(!items.length){
    els.list.innerHTML = `<li class="muted">No messages yet…</li>`;
    return;
  }
  els.list.innerHTML = '';
  items
    .sort((a,b)=> new Date(b.date) - new Date(a.date))
    .forEach(msg=>{
      const li = document.createElement('li');
      li.innerHTML = `
        <div class="from">${escapeHtml(msg.from || '')}</div>
        <div class="badge">#${msg.id}</div>
        <div class="subject">${escapeHtml(msg.subject || '(no subject)')}</div>
        <div class="date">${escapeHtml(msg.date || '')}</div>
      `;
      li.addEventListener('click', ()=> openMessage(msg.id));
      els.list.appendChild(li);
    });
}

async function openMessage(id){
  if(!id) return;
  state.currentId = id;
  els.viewer.innerHTML = `<div class="muted">Loading message…</div>`;
  try{
    const url = `${API}?action=readMessage&login=${encodeURIComponent(state.login)}&domain=${encodeURIComponent(state.domain)}&id=${id}`;
    const res = await fetch(url);
    const msg = await res.json();

    const headerHtml = `
      <div class="meta">
        <div class="item"><b>From:</b> ${escapeHtml(msg.from || '')}</div>
        <div class="item"><b>Subject:</b> ${escapeHtml(msg.subject || '(no subject)')}</div>
        <div class="item"><b>Date:</b> ${escapeHtml(msg.date || '')}</div>
      </div>
      <div class="actions">
        <button class="btn btn-outline" id="btnBack">⬅ Back</button>
        <button class="btn btn-danger" id="btnDelete">🗑 Delete</button>
      </div>
    `;

    // Body: prefer HTML body if present, else text
    let bodyHtml = '';
    if(msg.htmlBody){
      bodyHtml = `<iframe class="mail" sandbox srcdoc="${escapeAttr(msg.htmlBody)}"></iframe>`;
    } else if(msg.textBody){
      bodyHtml = `<pre style="white-space:pre-wrap;line-height:1.4">${escapeHtml(msg.textBody)}</pre>`;
    } else {
      bodyHtml = `<div class="muted">(Empty message)</div>`;
    }

    // Attachments
    let attachHtml = '';
    if(Array.isArray(msg.attachments) && msg.attachments.length){
      const links = msg.attachments.map(a=>{
        const dl = `${API}?action=download&login=${encodeURIComponent(state.login)}&domain=${encodeURIComponent(state.domain)}&id=${id}&file=${encodeURIComponent(a.filename)}`;
        return `<a href="${dl}" target="_blank" rel="noopener">${escapeHtml(a.filename)}</a>`;
      }).join('');
      attachHtml = `<div class="attachments"><b>Attachments:</b> ${links}</div>`;
    }

    els.viewer.innerHTML = `
      <div class="title"></div>
      ${headerHtml}
      ${attachHtml}
      ${bodyHtml}
    `;

    $('#btnBack').addEventListener('click', ()=> {
      els.viewer.innerHTML = `<div class="muted">Select a message to read</div>`;
    });
    $('#btnDelete').addEventListener('click', ()=> deleteMessage(id));

  } catch(e){
    els.viewer.innerHTML = `<div class="muted">Failed to load message.</div>`;
    console.error(e);
  }
}

async function deleteMessage(id){
  if(!confirm('Delete this message?')) return;
  try{
    const url = `${API}?action=deleteMessage&login=${encodeURIComponent(state.login)}&domain=${encodeURIComponent(state.domain)}&id=${id}`;
    await fetch(url);
    await refreshInbox();
    els.viewer.innerHTML = `<div class="muted">Message deleted.</div>`;
  } catch(e){
    alert('Failed to delete.');
    console.error(e);
  }
}

function copyAddress(){
  if(!state.address) return;
  navigator.clipboard?.writeText(state.address)
    .then(()=> toast('Copied!'))
    .catch(async ()=>{
      // Fallback
      const ta = document.createElement('textarea');
      ta.value = state.address;
      document.body.appendChild(ta);
      ta.select(); document.execCommand('copy');
      document.body.removeChild(ta);
      toast('Copied!');
    });
}

function toast(msg){
  setStatus(msg);
  setTimeout(()=> setStatus(`Last updated ${new Date().toLocaleTimeString()}`), 1200);
}

function newAddress(){
  if(state.timer) clearInterval(state.timer);
  localStorage.removeItem('tm_login');
  localStorage.removeItem('tm_domain');
  generateMailbox();
}

function setStatus(text){
  els.status.textContent = text;
}

function escapeHtml(s=''){
  return s.replace(/[&<>"']/g, c => (
    { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]
  ));
}
function escapeAttr(s=''){
  // Minimal attribute escaping for srcdoc
  return s.replace(/&/g,'&amp;').replace(/"/g,'&quot;');
}