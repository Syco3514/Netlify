import { db, json, requireUser } from './_lib/utils.js';

export const handler = async (event) => {
  if (event.httpMethod !== 'DELETE') return json({ error:'Method not allowed' }, 405);
  const user = await requireUser(event);
  if(!user) return json({ error:'Unauthorized' }, 401);

  const slug = decodeURIComponent((event.path || '').split('/').pop() || '');
  const link = await db.getJSON(`links/${slug}`);
  if(!link) return json({ error:'Not found' }, 404);
  if(link.ownerId !== user.id) return json({ error:'Forbidden' }, 403);

  await db.del(`links/${slug}`);
  await db.del(`userLinks/${user.id}/${slug}`);
  return json({ ok:true });
};