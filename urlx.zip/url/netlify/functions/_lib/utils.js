import { getStore } from '@netlify/blobs';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { customAlphabet } from 'nanoid';

const store = getStore(process.env.BLOBS_STORE || 'shorty'); // Netlify Blobs store name
const nano = customAlphabet('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', 7);
const RESERVED = new Set(['login','register','dashboard','api','assets','styles.css','favicon.ico','robots.txt']);

export const db = {
  async getJSON(key){ return await store.get(key, { type: 'json' }); },
  async setJSON(key, val){ return await store.set(key, JSON.stringify(val), { contentType: 'application/json' }); },
  async del(key){ return await store.delete(key); },
  async list(prefix){ return await store.list({ prefix }); }, // returns { blobs: [...] }
  store
};

export function json(body, status=200, headers={}){
  return {
    statusCode: status,
    headers: { 'content-type':'application/json; charset=utf-8', ...cors(), ...headers },
    body: JSON.stringify(body)
  };
}

export function html(body, status=200, headers={}){
  return {
    statusCode: status,
    headers: { 'content-type':'text/html; charset=utf-8', ...headers },
    body
  };
}

export function cors(){
  return {
    'access-control-allow-origin': process.env.SITE_URL || '*',
    'access-control-allow-credentials': 'true'
  };
}

export function parseJSON(event){
  try{ return JSON.parse(event.body || '{}'); } catch{ return {}; }
}

export function isEmail(v){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
export function isValidUsername(v){ return /^[a-zA-Z0-9_]{3,20}$/.test(v); }
export function isValidSlug(v){ return /^[a-zA-Z0-9_-]{3,30}$/.test(v) && !RESERVED.has(v.toLowerCase()); }
export function isValidURL(u){ try{ const x = new URL(u); return /^https?:$/.test(x.protocol); } catch { return false; } }

export async function hashPassword(pw){ return bcrypt.hash(pw, 10); }
export async function verifyPassword(pw, hash){ return bcrypt.compare(pw, hash); }

export function newId(){ return crypto.randomUUID(); }
export function newSessionId(){ return crypto.randomBytes(24).toString('hex'); }
export function newSlug(){ return nano(); }

export function setCookie(name, val, days=30){
  const expires = new Date(Date.now() + days*864e5).toUTCString();
  const parts = [`${name}=${val}; Path=/; Expires=${expires}; HttpOnly; SameSite=Lax`];
  if ((process.env.SITE_URL||'').startsWith('https:')) parts.push('Secure');
  return parts.join('; ');
}

export function clearCookie(name){
  return `${name}=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; SameSite=Lax`;
}

export function getCookie(event, name){
  const str = event.headers.cookie || event.headers.Cookie || '';
  const map = Object.fromEntries(str.split(';').map(v=>v.trim().split('=')));
  return map[name] || null;
}

export async function requireUser(event){
  const sid = getCookie(event,'sid');
  if(!sid) return null;
  const sess = await db.getJSON(`sessions/${sid}`);
  if(!sess || (sess.expiresAt && Date.now() > sess.expiresAt)) return null;
  const user = await db.getJSON(`users/${sess.userId}`);
  return user || null;
}

export function isBot(ua=''){
  ua = String(ua||'').toLowerCase();
  const bots = [
    'facebookexternalhit','facebot','twitterbot','slackbot','linkedinbot','discordbot','pinterest','skypeuripreview',
    'telegrambot','whatsapp','redditbot','quora link preview','vk share','nuzzel','embedly','bufferbot',
    'duckduckbot','bingbot','googlebot','yandex','baiduspider','ahrefsbot','semrush','mj12bot','crawler','spider','bot'
  ];
  return bots.some(b=> ua.includes(b));
}