import { db, json, requireUser } from './_lib/utils.js';

export const handler = async (event) => {
  if (event.httpMethod !== 'GET') return json({ error:'Method not allowed' }, 405);
  const user = await requireUser(event);
  if(!user) return json({ error:'Unauthorized' }, 401);

  const list = await db.list(`userLinks/${user.id}/`);
  const slugs = (list?.blobs||[]).map(b => b.key.split('/').pop());
  const links = [];
  for(const s of slugs){
    const l = await db.getJSON(`links/${s}`);
    if(l) links.push(l);
  }
  // sort newest first
  links.sort((a,b)=> b.createdAt - a.createdAt);
  return json({ links });
};