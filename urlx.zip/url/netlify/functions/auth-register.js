import { db, json, parseJSON, isEmail, isValidUsername, hashPassword, newId, newSessionId, setCookie } from './_lib/utils.js';

export const handler = async (event) => {
  if (event.httpMethod !== 'POST') return json({ error:'Method not allowed' }, 405);
  const { username, email, password } = parseJSON(event);

  if(!isValidUsername(username||'')) return json({ error:'Invalid username (3-20 chars, letters/numbers/_ )' }, 400);
  if(!isEmail(email||'')) return json({ error:'Invalid email' }, 400);
  if(!password || password.length < 8) return json({ error:'Password must be at least 8 characters' }, 400);

  // Uniqueness check
  const existingU = await db.getJSON(`usernames/${username.toLowerCase()}`);
  if(existingU) return json({ error:'Username already taken' }, 409);
  const existingE = await db.getJSON(`emails/${email.toLowerCase()}`);
  if(existingE) return json({ error:'Email already registered' }, 409);

  const userId = newId();
  const user = { id:userId, username, email: email.toLowerCase(), passwordHash: await hashPassword(password), createdAt: Date.now() };

  await db.setJSON(`users/${userId}`, user);
  await db.setJSON(`usernames/${username.toLowerCase()}`, { userId });
  await db.setJSON(`emails/${email.toLowerCase()}`, { userId });

  // Create session
  const sid = newSessionId();
  await db.setJSON(`sessions/${sid}`, { userId, createdAt: Date.now(), expiresAt: Date.now() + 30*864e5 });

  return {
    statusCode: 200,
    headers: {
      'content-type':'application/json; charset=utf-8',
      'set-cookie': setCookie('sid', sid),
    },
    body: JSON.stringify({ id:userId, username, email })
  };
};