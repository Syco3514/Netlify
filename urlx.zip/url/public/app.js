<script>
const api = {
  async json(url, opts = {}) {
    const res = await fetch(url, { credentials: 'include', headers: { 'Content-Type': 'application/json', ...(opts.headers||{}) }, ...opts });
    const txt = await res.text();
    let data = null; try { data = txt ? JSON.parse(txt) : null; } catch {}
    if (!res.ok) throw new Error((data && data.error) || txt || 'Request failed');
    return data;
  },
  me(){ return this.json('/api/me'); },
  login(payload){ return this.json('/api/login', { method:'POST', body: JSON.stringify(payload) }); },
  register(payload){ return this.json('/api/register', { method:'POST', body: JSON.stringify(payload) }); },
  logout(){ return this.json('/api/logout', { method:'POST' }); },
  createLink(payload){ return this.json('/api/links/create', { method:'POST', body: JSON.stringify(payload) }); },
  listLinks(){ return this.json('/api/links'); },
  deleteLink(slug){ return this.json('/api/links/'+encodeURIComponent(slug), { method:'DELETE' }); }
};

function setUserNav(user){
  const el = document.querySelector('#user-nav');
  if(!el) return;
  el.innerHTML = user
    ? `<span class="badge">Hi, ${user.username}</span> <button class="btn ghost" id="logoutBtn">Logout</button>`
    : `<a class="btn secondary" href="/login">Login</a> <a class="btn" href="/register">Create account</a>`;
  if (user) {
    const btn = document.getElementById('logoutBtn');
    btn && btn.addEventListener('click', async ()=>{
      try{ await api.logout(); location.href='/'; }catch(e){ alert(e.message); }
    });
  }
}

window.addEventListener('DOMContentLoaded', async ()=>{
  try {
    const me = await api.me().catch(()=>null);
    setUserNav(me);
  } catch {}
});
</script>